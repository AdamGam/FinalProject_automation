package pageObjects.grafana;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import java.util.List;

public class EditUserPage {

    @FindBy(how = How.XPATH, using = "//div/button/span[text()='Delete user']")
    public WebElement btn_deleteUser;

    @FindBy(how = How.XPATH, using = "//div[@class='css-1pvl9up-layoutChildrenWrapper'][2]")
    public WebElement btn_configDeleteUser;
}

//a[href='admin/users/edit/58']
//div/button[@class='css-mk7eo3-button']
//div[@class='css-1pvl9up-layoutChildrenWrapper'][2]
//div/button[@class='css-mk7eo3-button']

//div/button[@class='css-jigxr0-button']

//div[@class='css-1pvl9up-layoutChildrenWrapper'][2]

//div/button[@class='css-mk7eo3-button'][1]